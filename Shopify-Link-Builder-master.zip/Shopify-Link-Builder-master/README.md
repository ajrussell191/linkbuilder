# Shopify-Link-Builder
A simple shopify ATC link builder based in the discord API.

Setup:
Create a discord developer application and get a valid token. A tutorial can be found here: https://www.digitaltrends.com/gaming/how-to-make-a-discord-bot/

Once you have replaced the TOKEN variable you should be able to simply invite the bot to your server and start running it.

Commands:
Use !build <link> with the link to a shopify product and it will return ATC links.

This isn't meant to be very difficult or complex, but I want it to allow new developers to see examples of requests and how you can use them to make cool functional projects. If you have any questions shoot me an email: supmaster10@gmail.com
